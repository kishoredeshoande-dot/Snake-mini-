import React, { useState, useEffect, useRef, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  PanResponder,
  TouchableOpacity,
  Platform,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import * as Haptics from "expo-haptics";
import { Ionicons } from "@expo/vector-icons";
import Colors from "@/constants/colors";

const GRID_COLS = 20;
const GRID_ROWS = 20;

type Direction = "UP" | "DOWN" | "LEFT" | "RIGHT";
type GameState = "idle" | "playing" | "paused" | "gameover";
type Point = { x: number; y: number };

const { width: SCREEN_WIDTH } = Dimensions.get("window");
const BOARD_PADDING = 16;
const BOARD_SIZE = SCREEN_WIDTH - BOARD_PADDING * 2;
const CELL_SIZE = Math.floor(BOARD_SIZE / GRID_COLS);
const ACTUAL_BOARD_SIZE = CELL_SIZE * GRID_COLS;

const INITIAL_SNAKE: Point[] = [
  { x: 10, y: 10 },
  { x: 9, y: 10 },
  { x: 8, y: 10 },
];

const BASE_SPEED = 200;
const MIN_SPEED = 80;

function getSpeed(score: number): number {
  return Math.max(MIN_SPEED, BASE_SPEED - Math.floor(score / 3) * 10);
}

function randomFood(snake: Point[]): Point {
  let food: Point;
  do {
    food = {
      x: Math.floor(Math.random() * GRID_COLS),
      y: Math.floor(Math.random() * GRID_ROWS),
    };
  } while (snake.some((s) => s.x === food.x && s.y === food.y));
  return food;
}

const OPPOSITES: Record<Direction, Direction> = {
  UP: "DOWN",
  DOWN: "UP",
  LEFT: "RIGHT",
  RIGHT: "LEFT",
};

export default function SnakeGame() {
  const insets = useSafeAreaInsets();

  const [gameState, setGameState] = useState<GameState>("idle");
  const [snake, setSnake] = useState<Point[]>(INITIAL_SNAKE);
  const [food, setFood] = useState<Point>(() => randomFood(INITIAL_SNAKE));
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [isNewBest, setIsNewBest] = useState(false);

  // Refs for game loop (avoids stale closures)
  const gameStateRef = useRef<GameState>("idle");
  const snakeRef = useRef<Point[]>(INITIAL_SNAKE);
  const foodRef = useRef<Point>(food);
  const directionRef = useRef<Direction>("RIGHT");
  const pendingDirRef = useRef<Direction | null>(null);
  const scoreRef = useRef(0);
  const highScoreRef = useRef(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    AsyncStorage.getItem("snake_highscore").then((v) => {
      if (v) {
        const val = parseInt(v, 10);
        setHighScore(val);
        highScoreRef.current = val;
      }
    });
  }, []);

  const clearLoop = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  const scheduleLoop = (speed: number) => {
    clearLoop();
    intervalRef.current = setInterval(tick, speed);
  };

  const endGame = () => {
    clearLoop();
    gameStateRef.current = "gameover";
    setGameState("gameover");
    const finalScore = scoreRef.current;
    const newBest = finalScore > highScoreRef.current;
    setIsNewBest(newBest);
    if (newBest) {
      highScoreRef.current = finalScore;
      setHighScore(finalScore);
      AsyncStorage.setItem("snake_highscore", finalScore.toString());
    }
    Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
  };

  const tick = () => {
    if (gameStateRef.current !== "playing") return;

    const dir = pendingDirRef.current ?? directionRef.current;
    pendingDirRef.current = null;
    directionRef.current = dir;

    const head = snakeRef.current[0];
    let newHead: Point;

    switch (dir) {
      case "UP":
        newHead = { x: head.x, y: head.y - 1 };
        break;
      case "DOWN":
        newHead = { x: head.x, y: head.y + 1 };
        break;
      case "LEFT":
        newHead = { x: head.x - 1, y: head.y };
        break;
      case "RIGHT":
        newHead = { x: head.x + 1, y: head.y };
        break;
    }

    // Wall collision
    if (
      newHead.x < 0 ||
      newHead.x >= GRID_COLS ||
      newHead.y < 0 ||
      newHead.y >= GRID_ROWS
    ) {
      endGame();
      return;
    }

    // Self collision
    if (snakeRef.current.some((s) => s.x === newHead.x && s.y === newHead.y)) {
      endGame();
      return;
    }

    const ateFood =
      newHead.x === foodRef.current.x && newHead.y === foodRef.current.y;

    let newSnake: Point[];
    if (ateFood) {
      newSnake = [newHead, ...snakeRef.current];
      const newScore = scoreRef.current + 1;
      scoreRef.current = newScore;
      setScore(newScore);
      const newFood = randomFood(newSnake);
      foodRef.current = newFood;
      setFood(newFood);
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      scheduleLoop(getSpeed(newScore));
    } else {
      newSnake = [newHead, ...snakeRef.current.slice(0, -1)];
    }

    snakeRef.current = newSnake;
    setSnake([...newSnake]);
  };

  const startGame = useCallback(() => {
    const initSnake = INITIAL_SNAKE;
    const initFood = randomFood(initSnake);
    snakeRef.current = initSnake;
    foodRef.current = initFood;
    scoreRef.current = 0;
    directionRef.current = "RIGHT";
    pendingDirRef.current = null;

    setSnake(initSnake);
    setFood(initFood);
    setScore(0);
    setIsNewBest(false);

    gameStateRef.current = "playing";
    setGameState("playing");
    scheduleLoop(BASE_SPEED);
  }, []);

  const togglePause = useCallback(() => {
    if (gameStateRef.current === "playing") {
      clearLoop();
      gameStateRef.current = "paused";
      setGameState("paused");
    } else if (gameStateRef.current === "paused") {
      gameStateRef.current = "playing";
      setGameState("playing");
      scheduleLoop(getSpeed(scoreRef.current));
    }
  }, []);

  const changeDirection = useCallback((newDir: Direction) => {
    if (
      OPPOSITES[newDir] !== directionRef.current &&
      newDir !== directionRef.current
    ) {
      pendingDirRef.current = newDir;
    }
  }, []);

  useEffect(() => {
    return () => clearLoop();
  }, []);

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () =>
        gameStateRef.current === "playing",
      onMoveShouldSetPanResponder: () =>
        gameStateRef.current === "playing",
      onPanResponderEnd: (_, gs) => {
        const { dx, dy } = gs;
        if (Math.abs(dx) < 12 && Math.abs(dy) < 12) return;
        if (Math.abs(dx) > Math.abs(dy)) {
          if (OPPOSITES[dx > 0 ? "RIGHT" : "LEFT"] !== directionRef.current) {
            pendingDirRef.current = dx > 0 ? "RIGHT" : "LEFT";
          }
        } else {
          if (OPPOSITES[dy > 0 ? "DOWN" : "UP"] !== directionRef.current) {
            pendingDirRef.current = dy > 0 ? "DOWN" : "UP";
          }
        }
      },
    })
  ).current;

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;
  const speedLevel = Math.min(6, Math.floor(score / 3));

  return (
    <View
      style={[
        styles.container,
        { paddingTop: topPad + 8, paddingBottom: bottomPad + 8 },
      ]}
    >
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.scoreBlock}>
          <Text style={styles.scoreLabel}>SCORE</Text>
          <Text style={styles.scoreValue}>{score}</Text>
        </View>

        <Text style={styles.title}>SNAKE</Text>

        <View style={styles.scoreBlock}>
          <Text style={styles.scoreLabel}>BEST</Text>
          <Text style={styles.scoreValue}>{highScore}</Text>
        </View>
      </View>

      {/* Speed bar */}
      <View style={styles.speedRow}>
        <Text style={styles.speedLabel}>SPEED</Text>
        <View style={styles.speedBars}>
          {Array.from({ length: 6 }, (_, i) => (
            <View
              key={i}
              style={[
                styles.speedBar,
                i < speedLevel ? styles.speedBarOn : styles.speedBarOff,
              ]}
            />
          ))}
        </View>
      </View>

      {/* Board */}
      <View
        style={styles.boardWrapper}
        {...panResponder.panHandlers}
      >
        <View
          style={[
            styles.board,
            { width: ACTUAL_BOARD_SIZE, height: ACTUAL_BOARD_SIZE },
          ]}
        >
          {/* Grid lines */}
          {Array.from({ length: GRID_COLS + 1 }, (_, i) => (
            <View
              key={`v${i}`}
              style={[styles.gridV, { left: i * CELL_SIZE }]}
            />
          ))}
          {Array.from({ length: GRID_ROWS + 1 }, (_, i) => (
            <View
              key={`h${i}`}
              style={[styles.gridH, { top: i * CELL_SIZE }]}
            />
          ))}

          {/* Snake segments */}
          {snake.map((seg, i) => (
            <View
              key={`seg-${i}`}
              style={[
                styles.segment,
                {
                  left: seg.x * CELL_SIZE + 1,
                  top: seg.y * CELL_SIZE + 1,
                  width: CELL_SIZE - 2,
                  height: CELL_SIZE - 2,
                  backgroundColor:
                    i === 0
                      ? Colors.snakeHead
                      : i < 4
                      ? Colors.snakeBody
                      : Colors.snakeBodyDim,
                  borderRadius: i === 0 ? 5 : 3,
                  opacity: i === 0 ? 1 : Math.max(0.3, 1 - i * 0.035),
                },
              ]}
            />
          ))}

          {/* Food */}
          <View
            style={[
              styles.food,
              {
                left: food.x * CELL_SIZE + 3,
                top: food.y * CELL_SIZE + 3,
                width: CELL_SIZE - 6,
                height: CELL_SIZE - 6,
              },
            ]}
          />

          {/* Idle overlay */}
          {gameState === "idle" && (
            <View style={styles.overlay}>
              <View style={styles.overlayCard}>
                <Ionicons name="game-controller" size={48} color={Colors.accent} />
                <Text style={styles.overlayTitle}>SNAKE</Text>
                <Text style={styles.overlaySub}>
                  Swipe the board or use the{"\n"}D-pad to control the snake
                </Text>
                <TouchableOpacity
                  style={styles.ctaBtn}
                  onPress={startGame}
                  activeOpacity={0.85}
                >
                  <Text style={styles.ctaBtnText}>START GAME</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* Paused overlay */}
          {gameState === "paused" && (
            <View style={styles.overlay}>
              <View style={styles.overlayCard}>
                <Ionicons name="pause-circle" size={48} color={Colors.accent} />
                <Text style={styles.overlayTitle}>PAUSED</Text>
                <TouchableOpacity
                  style={styles.ctaBtn}
                  onPress={togglePause}
                  activeOpacity={0.85}
                >
                  <Text style={styles.ctaBtnText}>RESUME</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          {/* Game over overlay */}
          {gameState === "gameover" && (
            <View style={styles.overlay}>
              <View style={styles.overlayCard}>
                <Ionicons
                  name="skull-outline"
                  size={44}
                  color={Colors.danger}
                />
                <Text style={[styles.overlayTitle, { color: Colors.danger }]}>
                  GAME OVER
                </Text>
                <View style={styles.resultRow}>
                  <View style={styles.resultBlock}>
                    <Text style={styles.resultLabel}>SCORE</Text>
                    <Text style={styles.resultValue}>{score}</Text>
                  </View>
                  {isNewBest && score > 0 && (
                    <View style={styles.newBestBadge}>
                      <Text style={styles.newBestText}>NEW BEST</Text>
                    </View>
                  )}
                  <View style={styles.resultBlock}>
                    <Text style={styles.resultLabel}>BEST</Text>
                    <Text style={styles.resultValue}>{highScore}</Text>
                  </View>
                </View>
                <TouchableOpacity
                  style={styles.ctaBtn}
                  onPress={startGame}
                  activeOpacity={0.85}
                >
                  <Text style={styles.ctaBtnText}>PLAY AGAIN</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        </View>
      </View>

      {/* Controls area */}
      <View style={styles.controlsArea}>
        {(gameState === "playing" || gameState === "paused") && (
          <TouchableOpacity
            style={styles.pauseBtn}
            onPress={togglePause}
            activeOpacity={0.7}
          >
            <Ionicons
              name={gameState === "paused" ? "play" : "pause"}
              size={16}
              color={Colors.textSecondary}
            />
          </TouchableOpacity>
        )}

        {/* D-pad */}
        <View style={styles.dpad}>
          <View style={styles.dpadRow}>
            <TouchableOpacity
              style={styles.dpadBtn}
              onPress={() => changeDirection("UP")}
              activeOpacity={0.65}
            >
              <Ionicons name="chevron-up" size={20} color={Colors.textSecondary} />
            </TouchableOpacity>
          </View>
          <View style={styles.dpadRow}>
            <TouchableOpacity
              style={styles.dpadBtn}
              onPress={() => changeDirection("LEFT")}
              activeOpacity={0.65}
            >
              <Ionicons name="chevron-back" size={20} color={Colors.textSecondary} />
            </TouchableOpacity>
            <View style={[styles.dpadBtn, styles.dpadCenter]} />
            <TouchableOpacity
              style={styles.dpadBtn}
              onPress={() => changeDirection("RIGHT")}
              activeOpacity={0.65}
            >
              <Ionicons name="chevron-forward" size={20} color={Colors.textSecondary} />
            </TouchableOpacity>
          </View>
          <View style={styles.dpadRow}>
            <TouchableOpacity
              style={styles.dpadBtn}
              onPress={() => changeDirection("DOWN")}
              activeOpacity={0.65}
            >
              <Ionicons name="chevron-down" size={20} color={Colors.textSecondary} />
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </View>
  );
}

const DPAD_BTN_SIZE = 54;
const DPAD_GAP = 3;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    alignItems: "center",
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    width: "100%",
    paddingHorizontal: 28,
    marginBottom: 8,
  },
  scoreBlock: {
    alignItems: "center",
    minWidth: 70,
  },
  scoreLabel: {
    fontSize: 10,
    fontFamily: "Inter_600SemiBold",
    color: Colors.textMuted,
    letterSpacing: 2.5,
  },
  scoreValue: {
    fontSize: 30,
    fontFamily: "Inter_700Bold",
    color: Colors.accent,
    lineHeight: 36,
  },
  title: {
    fontSize: 20,
    fontFamily: "Inter_700Bold",
    color: Colors.textPrimary,
    letterSpacing: 7,
  },
  speedRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    marginBottom: 12,
  },
  speedLabel: {
    fontSize: 9,
    fontFamily: "Inter_600SemiBold",
    color: Colors.textMuted,
    letterSpacing: 2,
  },
  speedBars: {
    flexDirection: "row",
    gap: 3,
  },
  speedBar: {
    width: 14,
    height: 4,
    borderRadius: 2,
  },
  speedBarOn: {
    backgroundColor: Colors.accent,
  },
  speedBarOff: {
    backgroundColor: Colors.border,
  },
  boardWrapper: {
    alignItems: "center",
    justifyContent: "center",
  },
  board: {
    position: "relative",
    backgroundColor: Colors.grid,
    borderWidth: 1,
    borderColor: Colors.border,
    borderRadius: 6,
    overflow: "hidden",
  },
  gridV: {
    position: "absolute",
    top: 0,
    bottom: 0,
    width: 1,
    backgroundColor: Colors.gridLine,
  },
  gridH: {
    position: "absolute",
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: Colors.gridLine,
  },
  segment: {
    position: "absolute",
  },
  food: {
    position: "absolute",
    backgroundColor: Colors.food,
    borderRadius: 50,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "rgba(0,0,0,0.88)",
    alignItems: "center",
    justifyContent: "center",
    zIndex: 20,
  },
  overlayCard: {
    alignItems: "center",
    gap: 14,
    paddingHorizontal: 28,
  },
  overlayTitle: {
    fontSize: 30,
    fontFamily: "Inter_700Bold",
    color: Colors.textPrimary,
    letterSpacing: 6,
  },
  overlaySub: {
    fontSize: 13,
    fontFamily: "Inter_400Regular",
    color: Colors.textSecondary,
    textAlign: "center",
    lineHeight: 20,
  },
  ctaBtn: {
    marginTop: 6,
    backgroundColor: Colors.accent,
    paddingHorizontal: 36,
    paddingVertical: 14,
    borderRadius: 8,
    alignItems: "center",
    minWidth: 160,
  },
  ctaBtnText: {
    fontSize: 13,
    fontFamily: "Inter_700Bold",
    color: "#000000",
    letterSpacing: 2.5,
  },
  resultRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 16,
    marginVertical: 2,
  },
  resultBlock: {
    alignItems: "center",
  },
  resultLabel: {
    fontSize: 10,
    fontFamily: "Inter_600SemiBold",
    color: Colors.textMuted,
    letterSpacing: 2,
  },
  resultValue: {
    fontSize: 38,
    fontFamily: "Inter_700Bold",
    color: Colors.textPrimary,
    lineHeight: 46,
  },
  newBestBadge: {
    backgroundColor: Colors.accent,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 5,
  },
  newBestText: {
    fontSize: 9,
    fontFamily: "Inter_700Bold",
    color: "#000",
    letterSpacing: 1.5,
  },
  controlsArea: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
    paddingTop: 10,
  },
  pauseBtn: {
    position: "absolute",
    top: 6,
    right: 28,
    width: 36,
    height: 36,
    backgroundColor: Colors.surfaceElevated,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: "center",
    justifyContent: "center",
  },
  dpad: {
    gap: DPAD_GAP,
    alignItems: "center",
  },
  dpadRow: {
    flexDirection: "row",
    gap: DPAD_GAP,
    alignItems: "center",
  },
  dpadBtn: {
    width: DPAD_BTN_SIZE,
    height: DPAD_BTN_SIZE,
    backgroundColor: Colors.dpad,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: Colors.border,
    alignItems: "center",
    justifyContent: "center",
  },
  dpadCenter: {
    backgroundColor: Colors.dpad,
  },
});
